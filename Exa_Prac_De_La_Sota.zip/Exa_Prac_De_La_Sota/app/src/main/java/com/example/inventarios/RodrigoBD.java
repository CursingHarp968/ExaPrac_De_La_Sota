package com.example.inventarios;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class RodrigoBD extends SQLiteOpenHelper {
    private static final String Nombre_BD ="Rodrigo.bd";
    private static final int Version_BD = 1;
    private static final String Tabla_REGISTRO = "CREATE TABLE REGISTRO(CODIGO TEXT, DESCRIPCION TEXT, UBICACION TEXT, EXISTENCIAS TEXT)";

    public RodrigoBD(@Nullable Context context) {
        super(context, Nombre_BD, null, Version_BD);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
       sqLiteDatabase.execSQL(Tabla_REGISTRO);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS" + Tabla_REGISTRO);
        sqLiteDatabase.execSQL(Tabla_REGISTRO);
    }

    public void agregarRegistro (String CODIGO, String DESCRIPCION, String UBICACION, String EXISTENCIAS){
        SQLiteDatabase bd=getWritableDatabase();
        if (bd!=null){
            bd.execSQL("INSERT INTO REGISTRO VALUES ('"+CODIGO+"','"+DESCRIPCION+"','"+UBICACION+"','"+EXISTENCIAS+"')");
            bd.close();
        }
    }



    public void buscarRegistro (RegistrosModelo registro, String codigo){
        SQLiteDatabase bd=getReadableDatabase();
        Cursor cursor= bd.rawQuery("SELECT * FROM REGISTRO WHERE CODIGO = '"+codigo+"'", null);
        if (cursor.moveToFirst()){
            do {
                registro.setDescripcion(cursor.getString(1));
                registro.setUbicacion(cursor.getString(2));
                registro.setExistencias(cursor.getString(3));
            } while (cursor.moveToNext());
        }

    }

    public void editarRegistro (String CODIGO, String DESCRIPCION, String UBICACION, String EXISTENCIAS){
        SQLiteDatabase bd=getWritableDatabase();
        if (bd!=null){
            bd.execSQL("UPDATE REGISTRO SET DESCRIPCION = '"+DESCRIPCION+"', UBICACION = '"+UBICACION+"', EXISTENCIAS = '"+EXISTENCIAS+"' WHERE CODIGO = '"+CODIGO+"'");
            bd.close();
        }
    }

    public void eliminarRegistro (String CODIGO){
        SQLiteDatabase bd=getWritableDatabase();
        if (bd!=null){
            bd.execSQL("DELETE FROM REGISTRO WHERE CODIGO = '"+CODIGO+"'");
            bd.close();
        }
    }


}

package com.example.inventarios;

public class RegistrosModelo {
    private String codigo, descripcion, ubicacion, existencias;

    public RegistrosModelo(){
    }

    public RegistrosModelo(String codigo, String descripcion, String ubiacion, String existencias){
        this.codigo = codigo;
        this.descripcion = descripcion;
        this.ubicacion = ubiacion;
        this.existencias = existencias;
    }

    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) {this.codigo = codigo;}

    public String getDescripcion() { return descripcion; }
    public void setDescripcion(String descripcion) {this.descripcion = descripcion;}

    public String getUbicacion() { return ubicacion; }
    public void setUbicacion(String ubicacion) {this.ubicacion = ubicacion;}

    public String getExistencias() { return existencias; }
    public void setExistencias(String existencias) {this.existencias = existencias;}

}
package com.example.inventarios;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    EditText etNempleadoRD, etNombreRD, etPuestoRD, etDiasRD;
    Button btRegistrar, btConsultarRD, btEliminarRD, btEditarRD;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNempleadoRD =findViewById(R.id.etNempleado);
        etNombreRD =findViewById(R.id.etNombre);
        etPuestoRD =findViewById(R.id.etPuesto);
        etDiasRD =findViewById(R.id.etDias);

        btRegistrar=findViewById(R.id.btRegistrar);
        btConsultarRD =findViewById(R.id.btConsultar);
        btEliminarRD =findViewById(R.id.btEliminar);
        btEditarRD =findViewById(R.id.btEditar);

        final  RodrigoBD rodrigoBD=new RodrigoBD(getApplicationContext());

        btRegistrar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rodrigoBD.agregarRegistro(etNempleadoRD.getText().toString(), etNombreRD.getText().toString(), etPuestoRD.getText().toString(), etDiasRD.getText().toString());
                Toast.makeText(getApplicationContext(), "SE REGISTRO CORRECTAMENTE", Toast.LENGTH_SHORT).show();

            }
        });

        btConsultarRD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                RegistrosModelo registros=new RegistrosModelo();
                rodrigoBD.buscarRegistro(registros, etNempleadoRD.getText().toString());
                etNombreRD.setText(registros.getDescripcion());

                etDiasRD.setText(registros.getExistencias());

                int resultado = Integer.parseInt(registros.getUbicacion());

                if (resultado >= 16){
                    int bono = (int) (resultado * 0.15);
                    int total = resultado + bono;

                    etPuestoRD.setText(total);
                }else{
                    etPuestoRD.setText(registros.getUbicacion());
                }




            }
        });

        btEditarRD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rodrigoBD.editarRegistro(etNempleadoRD.getText().toString(), etNombreRD.getText().toString(), etPuestoRD.getText().toString(), etDiasRD.getText().toString());
                Toast.makeText(getApplicationContext(), "SE EDITO CORRECTAMENTE", Toast.LENGTH_SHORT).show();
            }
        });

        btEliminarRD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                rodrigoBD.eliminarRegistro(etNempleadoRD.getText().toString());
                Toast.makeText(getApplicationContext(), "SE ELIMINO CORRECTAMENTE", Toast.LENGTH_SHORT).show();
            }
        });


    }

}